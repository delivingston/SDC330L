
/*
 * Name: Dale Livingston II
 * Date: October 18, 2026
 * Assignment: Week 2 Project - Phase 2
 * Description: IRA account class that inherits BankAccount.
 */

// Inheritance: IRAAccount extends BankAccount.
public class IRAAccount extends BankAccount {

    private double interestRate;
    private String iraType;

    public IRAAccount(int accountNumber, double balance,
                      Customer customer, double interestRate,
                      String iraType) {

        super(accountNumber, balance, customer);

        this.interestRate = interestRate;
        this.iraType = iraType;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public String getIraType() {
        return iraType;
    }

    public void setIraType(String iraType) {
        this.iraType = iraType;
    }

    @Override
    public String toString() {
        return "Account Type: IRA\n"
            + super.toString()
            + "\nIRA Type: " + iraType
            + "\nInterest Rate: " + interestRate + "%";
    }
}
