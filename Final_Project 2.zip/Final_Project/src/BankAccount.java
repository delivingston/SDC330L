
/*
 * Name: Dale Livingston II
 * Date: October 10, 2026
 * Assignment: Week 1 Project - Phase 1
 * Description: Parent class that stores bank account information.
 */

public class BankAccount implements BankingOperations {

    private int accountNumber;
    private double balance;

    // Composition: BankAccount contains a Customer object.
    private Customer customer;

    public BankAccount(int accountNumber, double balance,
                       Customer customer) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.customer = customer;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return customer.toString()
            + "\nAccount Number: " + accountNumber
            + "\nBalance: $" + String.format("%.2f", balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }else {
            System.out.println("Invalid deposit amount.");
        }
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }

    return false;
}

}
