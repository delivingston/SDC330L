/*
 * Name: Dale Livingston II
 * Date: October 18, 2026
 * Assignment: Week 2 Project - Phase 2
 * Description: Defines basic banking transactions for accounts.
 */
public interface BankingOperations {
    void deposit(double amount);
    boolean withdraw(double amount);
}
