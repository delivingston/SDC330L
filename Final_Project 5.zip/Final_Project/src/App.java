/*
 * Name: Dale Livingston II
 * Date: October 31, 2026
 * Assignment: Week 5 Project - Final Phase
 * Description: Bank Account Management System using SQLite.
 * Includes Create, Read, Update, and Delete operations.
 */

import java.sql.SQLException;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        // Create the database manager object.
        DatabaseManager db = new DatabaseManager();

        // Initialize the SQLite database.
        try {
            db.initialize();

        } catch (SQLException e) {
            System.out.println("Could not start database: " + e.getMessage());
            return;
        }

        try (Scanner input = new Scanner(System.in)) {

            int choice = 0;

            // Welcome message
            System.out.println("========================================");
            System.out.println("Bank Account Management System");
            System.out.println("Created by: Dale Livingston II");
            System.out.println("Week 5 Project - Final Project");
            System.out.println("========================================");

            System.out.println("\nWelcome to the Banking System!");
            System.out.println("This application allows you to manage");
            System.out.println("customers and their bank accounts.");
            System.out.println("You can create, view, update, and delete");
            System.out.println("information stored in the SQLite database.");

            // Keep displaying the menu until the user exits.
            while (choice != 9) {

                System.out.println("\n========== Banking Menu ==========");
                System.out.println("1. View All Accounts");
                System.out.println("2. View Account by Number");
                System.out.println("3. Add New Customer");
                System.out.println("4. Create New Bank Account");
                System.out.println("5. Deposit Money");
                System.out.println("6. Withdraw Money");
                System.out.println("7. Update Customer Information");
                System.out.println("8. Delete Bank Account");
                System.out.println("9. Exit");
                System.out.println("==================================");

                choice = readInt(input, "Enter your choice: ");

                try {

                    switch (choice) {

                        // READ: Display all accounts.
                        case 1 -> {

                            System.out.println("\n===== All Bank Accounts =====");

                            db.showAllAccounts();
                        }

                        // READ: Search for an account.
                        case 2 -> {

                            int number = readInt(
                                input, "Enter account number: "
                            );

                            BankAccount account = db.getAccount(number);

                            if (account != null) {

                                System.out.println("\n===== Account Information =====");
                                System.out.println(account);

                            } else {

                                System.out.println("Account not found.");
                            }
                        }

                        // CREATE: Add a new customer.
                        case 3 -> {

                            int id = readInt(
                                input, "Enter new customer ID: "
                            );

                            String name = readText(
                                input, "Enter customer name: "
                            );

                            db.addCustomer(id, name);

                            System.out.println("Customer added successfully!");
                        }

                        // CREATE: Add a new bank account.
                        case 4 -> {

                            createAccount(input, db);
                        }

                        // UPDATE: Deposit money.
                        case 5 -> {

                            int number = readInt(
                                input, "Enter account number: "
                            );

                            double amount = readDouble(
                                input, "Enter deposit amount: $"
                            );

                            boolean success = db.updateBalance(
                                number, amount, true
                            );

                            if (success) {

                                System.out.println("Deposit successful!");
                                System.out.println(db.getAccount(number));

                            } else {

                                System.out.println(
                                    "Deposit failed. Check the account number and amount."
                                );
                            }
                        }

                        // UPDATE: Withdraw money.
                        case 6 -> {

                            int number = readInt(
                                input, "Enter account number: "
                            );

                            double amount = readDouble(
                                input, "Enter withdrawal amount: $"
                            );

                            boolean success = db.updateBalance(
                                number, amount, false
                            );

                            if (success) {

                                System.out.println("Withdrawal successful!");
                                System.out.println(db.getAccount(number));

                            } else {

                                System.out.println(
                                    "Withdrawal failed. Check the balance and amount."
                                );
                            }
                        }

                        // UPDATE: Change customer information.
                        case 7 -> {

                            int id = readInt(
                                input, "Enter customer ID: "
                            );

                            String name = readText(
                                input, "Enter updated customer name: "
                            );

                            boolean updated = db.updateCustomer(id, name);

                            if (updated) {

                                System.out.println(
                                    "Customer information updated successfully!"
                                );

                            } else {

                                System.out.println("Customer not found.");
                            }
                        }

                        // DELETE: Remove an account.
                        case 8 -> {

                            int number = readInt(
                                input, "Enter account number to delete: "
                            );

                            String confirm = readText(
                                input, "Type YES to confirm deletion: "
                            );

                            if (confirm.equalsIgnoreCase("YES")) {

                                boolean deleted = db.deleteAccount(number);

                                if (deleted) {

                                    System.out.println(
                                        "Account deleted successfully!"
                                    );

                                } else {

                                    System.out.println("Account not found.");
                                }

                            } else {

                                System.out.println("Deletion canceled.");
                            }
                        }

                        // Exit application.
                        case 9 -> {

                            System.out.println(
                                "\nThank you for using the Banking System!"
                            );
                        }

                        // Invalid menu choice.
                        default -> {

                            System.out.println(
                                "Invalid choice. Please try again."
                            );
                        }
                    }

                } catch (SQLException e) {

                    System.out.println(
                        "Database error: " + e.getMessage()
                    );
                }
            }
        }
    }

    // CREATE: Create a checking, savings, or IRA account.
    // Uses constructors, abstraction, and inheritance.
    private static void createAccount(
        Scanner input, DatabaseManager db
    ) throws SQLException {

        int customerId = readInt(
            input, "Enter existing customer ID: "
        );

        // Check if the customer exists in the database.
        if (!db.customerExists(customerId)) {

            System.out.println("Customer not found.");
            System.out.println("Please add the customer first.");

            return;
        }

        int number = readInt(
            input, "Enter new account number: "
        );

        System.out.println("\nSelect Account Type:");
        System.out.println("1. Checking");
        System.out.println("2. Savings");
        System.out.println("3. IRA");

        int type = readInt(input, "Enter account type: ");

        if (type < 1 || type > 3) {

            System.out.println("Invalid account type.");
            return;
        }

        double balance = readDouble(
            input, "Enter opening balance: $"
        );

        if (balance < 0) {

            System.out.println("Balance cannot be negative.");
            return;
        }

        // Constructor initializes customer information.
        Customer customer = new Customer("", customerId);

        // Abstraction: BankAccount is the parent class.
        BankAccount account;

        switch (type) {

            // Create checking account.
            case 1 -> {

                double limit = readDouble(
                    input, "Enter overdraft limit: $"
                );

                if (limit < 0) {

                    System.out.println("Invalid overdraft limit.");
                    return;
                }

                account = new CheckingAccount(
                    number, balance, customer, limit
                );
            }

            // Create savings account.
            case 2 -> {

                double rate = readDouble(
                    input, "Enter interest rate (%): "
                );

                if (rate < 0) {

                    System.out.println("Invalid interest rate.");
                    return;
                }

                account = new SavingsAccount(
                    number, balance, customer, rate
                );
            }

            // Create IRA account.
            default -> {

                double rate = readDouble(
                    input, "Enter interest rate (%): "
                );

                if (rate < 0) {

                    System.out.println("Invalid interest rate.");
                    return;
                }

                String iraType = readText(
                    input, "Enter IRA type (Roth or Traditional): "
                );

                account = new IRAAccount(
                    number, balance, customer, rate, iraType
                );
            }
        }

        // Save the new account to SQLite.
        db.addAccount(account);

        System.out.println("\nAccount created successfully!");
    }

    // Validate integer input.
    private static int readInt(
        Scanner input, String prompt
    ) {

        while (true) {

            System.out.print(prompt);

            String value = input.nextLine();

            try {

                return Integer.parseInt(value.trim());

            } catch (NumberFormatException e) {

                System.out.println(
                    "Invalid input. Please enter a whole number."
                );
            }
        }
    }

    // Validate decimal input.
    private static double readDouble(
        Scanner input, String prompt
    ) {

        while (true) {

            System.out.print(prompt);

            String value = input.nextLine();

            try {

                double amount = Double.parseDouble(value.trim());

                if (Double.isFinite(amount)) {
                    return amount;
                }

            } catch (NumberFormatException e) {

                System.out.println("Invalid number.");
            }

            System.out.println(
                "Please enter a valid amount."
            );
        }
    }

    // Validate text input.
    private static String readText(
        Scanner input, String prompt
    ) {

        while (true) {

            System.out.print(prompt);

            String text = input.nextLine().trim();

            if (!text.isEmpty()) {

                return text;
            }

            System.out.println(
                "Input cannot be empty. Please try again."
            );
        }
    }
}