/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Checking account class that inherits BankAccount.
 */

public class CheckingAccount extends BankAccount {

    private double overdraftLimit;

    public CheckingAccount(int accountNumber, double balance,
                           Customer customer, double overdraftLimit) {

        super(accountNumber, balance, customer);
        this.overdraftLimit = overdraftLimit;
    }

    // Overloaded constructor.
    public CheckingAccount(int accountNumber, Customer customer,
                           double overdraftLimit) {
        this(accountNumber, 0.0, customer, overdraftLimit);
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }

    public void setOverdraftLimit(double overdraftLimit) {
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public String getAccountType() {
        return "Checking";
    }

    @Override
    public String toString() {
        return "Account Type: Checking\n"
            + super.toString()
            + "\nOverdraft Limit: $"
            + String.format("%.2f", overdraftLimit);
    }
}