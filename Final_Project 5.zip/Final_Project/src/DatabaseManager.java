/*
 * Name: Dale Livingston II
 * Date: October 31, 2026
 * Assignment: Week 4 Project - Phase 4
 * Description: Manages the SQLite database for the banking system.
 * Includes Create, Read, Update, and Delete operations.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class DatabaseManager {

    private static final String URL = "jdbc:sqlite:banking.db";

    // Connect to SQLite database.
    // Private access prevents other classes from calling this directly.
    private Connection connect() throws SQLException {

        Connection connection = DriverManager.getConnection(URL);

        try (Statement statement = connection.createStatement()) {

            // Wait up to 10 seconds if the database is locked.
            statement.execute("PRAGMA busy_timeout = 10000");

            // Enable foreign key relationships.
            statement.execute("PRAGMA foreign_keys = ON");

        } catch (SQLException e) {
            connection.close();
            throw e;
        }

        return connection;
    }

    // Create database tables when the application starts.
    public void initialize() throws SQLException {

        String customersTable =
            "CREATE TABLE IF NOT EXISTS customers (" +
            "customer_id INTEGER PRIMARY KEY, " +
            "name TEXT NOT NULL)";

        String accountsTable =
            "CREATE TABLE IF NOT EXISTS accounts (" +
            "account_number INTEGER PRIMARY KEY, " +
            "customer_id INTEGER NOT NULL, " +
            "account_type TEXT NOT NULL, " +
            "balance REAL NOT NULL DEFAULT 0, " +
            "overdraft_limit REAL, " +
            "interest_rate REAL, " +
            "ira_type TEXT, " +
            "FOREIGN KEY(customer_id) " +
            "REFERENCES customers(customer_id))";

        try (Connection connection = connect();
             Statement statement = connection.createStatement()) {

            statement.executeUpdate(customersTable);
            statement.executeUpdate(accountsTable);
        }

        // Check whether sample data needs to be added.
        boolean databaseEmpty = false;

        try (Connection connection = connect();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(
                 "SELECT COUNT(*) FROM customers"
             )) {

            if (rs.next()) {
                databaseEmpty = rs.getInt(1) == 0;
            }
        }

        // Previous connection is closed before inserting records.
        if (databaseEmpty) {

            addCustomer(1001, "John Smith");
            addCustomer(1002, "Maria Johnson");
            addCustomer(1003, "David Williams");

            addAccount(new CheckingAccount(
                12345, 1500.00,
                new Customer("John Smith", 1001),
                500.00
            ));

            addAccount(new SavingsAccount(
                67890, 3000.00,
                new Customer("John Smith", 1001),
                2.5
            ));

            addAccount(new IRAAccount(
                24680, 8500.00,
                new Customer("Maria Johnson", 1002),
                3.5, "Roth"
            ));

            addAccount(new SavingsAccount(
                13579, 2250.00,
                new Customer("David Williams", 1003),
                2.0
            ));
        }
    }

    // CREATE: Add a new customer.
    public void addCustomer(int id, String name) throws SQLException {

        String sql =
            "INSERT INTO customers(customer_id, name) VALUES (?, ?)";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.setString(2, name);

            ps.executeUpdate();
        }
    }

    // READ: Check if a customer exists.
    public boolean customerExists(int id) throws SQLException {

        String sql =
            "SELECT 1 FROM customers WHERE customer_id = ?";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // CREATE: Add a new bank account.
    public void addAccount(BankAccount account) throws SQLException {

        String sql =
            "INSERT INTO accounts (" +
            "account_number, customer_id, account_type, balance, " +
            "overdraft_limit, interest_rate, ira_type) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, account.getAccountNumber());

            ps.setInt(
                2, account.getCustomer().getCustomerId()
            );

            ps.setString(3, account.getAccountType());
            ps.setDouble(4, account.getBalance());

            // Checking account overdraft limit.
            if (account instanceof CheckingAccount) {

                CheckingAccount checking =
                    (CheckingAccount) account;

                ps.setDouble(
                    5, checking.getOverdraftLimit()
                );

            } else {
                ps.setNull(5, Types.REAL);
            }

            // Savings account interest rate.
            if (account instanceof SavingsAccount) {

                SavingsAccount savings =
                    (SavingsAccount) account;

                ps.setDouble(
                    6, savings.getInterestRate()
                );

            } else if (account instanceof IRAAccount) {

                IRAAccount ira =
                    (IRAAccount) account;

                ps.setDouble(
                    6, ira.getInterestRate()
                );

            } else {
                ps.setNull(6, Types.REAL);
            }

            // IRA account type.
            if (account instanceof IRAAccount) {

                IRAAccount ira =
                    (IRAAccount) account;

                ps.setString(
                    7, ira.getIraType()
                );

            } else {
                ps.setNull(7, Types.VARCHAR);
            }

            ps.executeUpdate();
        }
    }

    // Convert SQLite records into BankAccount objects.
    // Demonstrates abstraction and polymorphism.
    private BankAccount fromRow(ResultSet rs) throws SQLException {

        Customer customer = new Customer(
            rs.getString("name"),
            rs.getInt("customer_id")
        );

        int number = rs.getInt("account_number");
        double balance = rs.getDouble("balance");

        String type = rs.getString("account_type");

        switch (type) {

            case "Checking" -> {
                return new CheckingAccount(
                        number,
                        balance,
                        customer,
                        rs.getDouble("overdraft_limit")
                );
            }

            case "Savings" -> {
                return new SavingsAccount(
                        number,
                        balance,
                        customer,
                        rs.getDouble("interest_rate")
                );
            }

            case "IRA" -> {
                return new IRAAccount(
                        number,
                        balance,
                        customer,
                        rs.getDouble("interest_rate"),
                        rs.getString("ira_type")
                );
            }

            default -> throw new SQLException(
                    "Unknown account type: " + type
                );
        }
    }

    // SQL query shared by account retrieval methods.
    private static final String ACCOUNT_QUERY =
        "SELECT a.*, c.name FROM accounts a " +
        "JOIN customers c ON a.customer_id = c.customer_id";

    // READ: Display all bank accounts.
    public void showAllAccounts() throws SQLException {

        String sql =
            ACCOUNT_QUERY + " ORDER BY a.account_number";

        try (Connection connection = connect();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            boolean found = false;

            System.out.println("\n===== All Bank Accounts =====");

            while (rs.next()) {

                found = true;

                BankAccount account = fromRow(rs);

                System.out.println("\n--------------------------");
                System.out.println(account);
            }

            if (!found) {
                System.out.println("No accounts found.");
            }
        }
    }

    // READ: Search for an account by account number.
    public BankAccount getAccount(int number) throws SQLException {

        String sql =
            ACCOUNT_QUERY + " WHERE a.account_number = ?";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, number);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return fromRow(rs);
                }

                return null;
            }
        }
    }

    // UPDATE: Deposit or withdraw money.
    public boolean updateBalance(
        int number, double amount, boolean deposit
    ) throws SQLException {

        if (amount <= 0 || !Double.isFinite(amount)) {
            return false;
        }

        String sql;

        if (deposit) {

            sql =
                "UPDATE accounts " +
                "SET balance = ROUND(balance + ?, 2) " +
                "WHERE account_number = ?";

        } else {

            sql =
                "UPDATE accounts " +
                "SET balance = ROUND(balance - ?, 2) " +
                "WHERE account_number = ? AND balance >= ?";
        }

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setDouble(1, amount);
            ps.setInt(2, number);

            if (!deposit) {
                ps.setDouble(3, amount);
            }

            int rowsUpdated = ps.executeUpdate();

            return rowsUpdated > 0;
        }
    }

    // UPDATE: Change customer information.
    public boolean updateCustomer(
        int id, String name
    ) throws SQLException {

        String sql =
            "UPDATE customers SET name = ? WHERE customer_id = ?";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setInt(2, id);

            int rowsUpdated = ps.executeUpdate();

            return rowsUpdated > 0;
        }
    }

    // DELETE: Remove an account from the database.
    public boolean deleteAccount(int number) throws SQLException {

        String sql =
            "DELETE FROM accounts WHERE account_number = ?";

        try (Connection connection = connect();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, number);

            int rowsDeleted = ps.executeUpdate();

            return rowsDeleted > 0;
        }
    }
}