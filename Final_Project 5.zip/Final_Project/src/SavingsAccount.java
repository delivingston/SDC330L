/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Savings account class that inherits BankAccount.
 */

public class SavingsAccount extends BankAccount {

    private double interestRate;

    public SavingsAccount(int accountNumber, double balance,
                          Customer customer, double interestRate) {

        super(accountNumber, balance, customer);
        this.interestRate = interestRate;
    }

    // Overloaded constructor.
    public SavingsAccount(int accountNumber, Customer customer,
                          double interestRate) {
        this(accountNumber, 0.0, customer, interestRate);
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public String getAccountType() {
        return "Savings";
    }

    @Override
    public String toString() {
        return "Account Type: Savings\n"
            + super.toString()
            + "\nInterest Rate: " + interestRate + "%";
    }
}