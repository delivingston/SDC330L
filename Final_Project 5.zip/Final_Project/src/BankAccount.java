/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Parent class that stores bank account information.
 */

public abstract class BankAccount implements BankingOperations {

    private int accountNumber;
    private double balance;

    // Composition: BankAccount contains a Customer object.
    private Customer customer;

    protected BankAccount(int accountNumber, double balance,
                          Customer customer) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.customer = customer;
    }

    // Overloaded constructor: starts with zero balance.
    protected BankAccount(int accountNumber, Customer customer) {
        this(accountNumber, 0.0, customer);
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    protected void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    protected void setBalance(double balance) {
        this.balance = balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    protected void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // Abstraction: Child classes must identify their account type.
    public abstract String getAccountType();

    @Override
    public String toString() {
        return customer.toString()
            + "\nAccount Number: " + accountNumber
            + "\nBalance: $" + String.format("%.2f", balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }

        return false;
    }
}