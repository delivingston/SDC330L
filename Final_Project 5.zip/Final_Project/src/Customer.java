/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Stores customer information for a bank account.
 */

public class Customer {

    private String name;
    private int customerId;

    public Customer(String name, int customerId) {
        this.name = name;
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    @Override
    public String toString() {
        return "Customer Name: " + name
            + "\nCustomer ID: " + customerId;
    }
}