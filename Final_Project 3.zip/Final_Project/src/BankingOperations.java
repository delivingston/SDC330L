
/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Defines basic banking transactions for accounts.
 */

public interface BankingOperations {

    void deposit(double amount);

    boolean withdraw(double amount);
}
