
/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: Week 3 Project - Phase 3
 * Description: Bank Account Management System with
 * abstraction, constructors, inheritance, and input validation.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {

            int choice = 0;

            // Welcome message
            System.out.println("====================================");
            System.out.println("Bank Account Management System");
            System.out.println("Created by: Dale Livingston II");
            System.out.println("Week 3 - Abstraction, Constructors, and Access Specifiers");
            System.out.println("====================================");

            System.out.println("\nWelcome to the Banking System!");
            System.out.println("Use the menu to view accounts, make deposits or withdrawals, or exit.");

            // Create customer
            Customer customer = new Customer("John Smith", 1001);

            // Constructors initialize the account information.
            CheckingAccount checking = new CheckingAccount(
                12345, 1500.00, customer, 500.00
            );

            SavingsAccount savings = new SavingsAccount(
                67890, 3000.00, customer, 2.5
            );

            IRAAccount ira = new IRAAccount(
                24680, 8500.00, customer, 3.5, "Roth"
            );

            // Polymorphism: Store different account types.
            ArrayList<BankAccount> accounts = new ArrayList<>();

            accounts.add(checking);
            accounts.add(savings);
            accounts.add(ira);

            // Constructor overloading: Create an account with $0.
            SavingsAccount newSavings = new SavingsAccount(
                13579, customer, 2.0
            );

            accounts.add(newSavings);

            // Keep displaying the menu until the user exits.
            while (choice != 11) {

                System.out.println("\n===== Banking Menu =====");
                System.out.println("1. View All Accounts");
                System.out.println("2. Deposit to Checking");
                System.out.println("3. Deposit to Savings");
                System.out.println("4. Deposit to IRA");
                System.out.println("5. Withdraw from Checking");
                System.out.println("6. Withdraw from Savings");
                System.out.println("7. Withdraw from IRA");
                System.out.println("8. View Checking Account");
                System.out.println("9. View Savings Account");
                System.out.println("10. View IRA Account");
                System.out.println("11. Exit");
                System.out.print("Enter your choice: ");

                // Validate menu input
                if (input.hasNextInt()) {
                    choice = input.nextInt();
                } else {
                    System.out.println("That is not a valid integer!");
                    input.next();
                    continue;
                }

                switch (choice) {

                    case 1 -> {
                        System.out.println("\n===== All Accounts =====");

                        // Polymorphism: Each subclass uses its
                        // own overridden toString() method.
                        for (BankAccount account : accounts) {
                            printAccount(account);
                        }
                    }

                    case 2 -> {
                        System.out.print("Deposit to Checking: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (amount > 0) {
                                checking.deposit(amount);
                                System.out.println("Deposit successful!");
                                printAccount(checking);
                            } else {
                                System.out.println("Amount must be greater than zero.");
                            }
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 3 -> {
                        System.out.print("Deposit to Savings: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (amount > 0) {
                                savings.deposit(amount);
                                System.out.println("Deposit successful!");
                                printAccount(savings);
                            } else {
                                System.out.println("Amount must be greater than zero.");
                            }
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 4 -> {
                        System.out.print("Deposit to IRA: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (amount > 0) {
                                ira.deposit(amount);
                                System.out.println("Deposit successful!");
                                printAccount(ira);
                            } else {
                                System.out.println("Amount must be greater than zero.");
                            }
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 5 -> {
                        System.out.print("Withdraw from Checking: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (checking.withdraw(amount)) {
                                System.out.println("Withdrawal successful!");
                            } else {
                                System.out.println("Invalid amount or insufficient funds.");
                            }

                            printAccount(checking);
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 6 -> {
                        System.out.print("Withdraw from Savings: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (savings.withdraw(amount)) {
                                System.out.println("Withdrawal successful!");
                            } else {
                                System.out.println("Invalid amount or insufficient funds.");
                            }

                            printAccount(savings);
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 7 -> {
                        System.out.print("Withdraw from IRA: $");

                        if (input.hasNextDouble()) {
                            double amount = input.nextDouble();

                            if (ira.withdraw(amount)) {
                                System.out.println("Withdrawal successful!");
                            } else {
                                System.out.println("Invalid amount or insufficient funds.");
                            }

                            printAccount(ira);
                        } else {
                            System.out.println("Invalid amount!");
                            input.next();
                        }
                    }

                    case 8 -> {
                        System.out.println("\n===== Checking Account =====");
                        printAccount(checking);
                    }

                    case 9 -> {
                        System.out.println("\n===== Savings Account =====");
                        printAccount(savings);
                    }

                    case 10 -> {
                        System.out.println("\n===== IRA Account =====");
                        printAccount(ira);
                    }

                    case 11 -> {
                        System.out.println("\nThank you for using the Banking System!");
                    }

                    default -> {
                        System.out.println("Invalid choice. Try again.");
                    }
                }
            }
        }
    }

    // Polymorphism: Accepts any subclass of BankAccount.
    private static void printAccount(BankAccount account) {
        System.out.println("\n" + account.toString());
    }
}
