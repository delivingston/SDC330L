
/*
 * Name: Dale Livingston II
 * Date: October 10, 2026
 * Assignment: Week 1 Project - Phase 1
 * Description: Checking account class that inherits BankAccount.
 */

// Inheritance: CheckingAccount extends BankAccount.
public class CheckingAccount extends BankAccount {

    private double overdraftLimit;

    public CheckingAccount(int accountNumber, double balance,
                           Customer customer,
                           double overdraftLimit) {

        super(accountNumber, balance, customer);
        this.overdraftLimit = overdraftLimit;
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }

    public void setOverdraftLimit(double overdraftLimit) {
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public String toString() {
        return "Account Type: Checking\n"
            + super.toString()
            + "\nOverdraft Limit: $"
            + String.format("%.2f", overdraftLimit);
    }
}
