
/*
 * Name: Dale Livingston II
 * Date: October 10, 2026
 * Assignment: Week 1 Project - Phase 1
 * Description: Savings account class that inherits BankAccount.
 */

// Inheritance: SavingsAccount extends BankAccount.
public class SavingsAccount extends BankAccount {

    private double interestRate;

    public SavingsAccount(int accountNumber, double balance,
                          Customer customer,
                          double interestRate) {

        super(accountNumber, balance, customer);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public String toString() {
        return "Account Type: Savings\n"
            + super.toString()
            + "\nInterest Rate: " + interestRate + "%";
    }
}
