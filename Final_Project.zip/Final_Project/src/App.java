
/*
 * Name: Dale Livingston II
 * Date: October 10, 2026
 * Assignment: Week 1 Project - Phase 1
 * Description: Main program with a banking menu.
 */

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int choice = 0;

        // Welcome message and project information
        System.out.println("=================================");
        System.out.println("Bank Account Management System");
        System.out.println("Created by: Dale Livingston II");
        System.out.println("=================================");

        System.out.println("\nWelcome to the Banking System!");
        System.out.println("This program allows you to view");
        System.out.println("checking and savings account information.");

        // Create a customer
        Customer customer = new Customer("John Smith", 1001);

        // Create checking and savings accounts
        CheckingAccount checking = new CheckingAccount(
            12345, 1500.00, customer, 500.00
        );

        SavingsAccount savings = new SavingsAccount(
            67890, 3000.00, customer, 2.5
        );


        // Keep showing the menu until the user exits
        while (choice != 4) {

            System.out.println("\n===== Banking Menu =====");
            System.out.println("1. View Checking Account");
            System.out.println("2. View Savings Account");
            System.out.println("3. View All Accounts");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            System.out.print("Enter your choice: ");

            choice = input.nextInt(); // Reads the number entered by the user

            switch (choice) {
                case 1:
                System.out.println("\n" + checking.toString());
                break;

            case 2:
                System.out.println("\n" + savings.toString());
                break;

            case 3:
                System.out.println("\n" + checking.toString());
                System.out.println("\n" + savings.toString());
                break;

            case 4:
                System.out.println("\nThank you for using the Banking System!");
                break;

            default:
                System.out.println("Invalid choice. Try again.");
            }
        }
        input.close();
    }
}
